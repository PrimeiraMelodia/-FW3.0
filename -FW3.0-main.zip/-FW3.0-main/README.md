# -FW3.0
interoperabilidade, descentralização enfim viver com liberdade, Fundação Web3 chega para ajudar grandes empresas e pessoas visionarias a governança sem taxas e impostos por um planeta mais verde e com vida. 
